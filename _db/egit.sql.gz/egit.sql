-- Adminer 4.8.4 MySQL 8.2.0 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `sign_logs`;
CREATE TABLE `sign_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_sign` datetime NOT NULL,
  `ip_address` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

INSERT INTO `sign_logs` (`id`, `date_sign`, `ip_address`) VALUES
(1,	'2025-04-08 10:03:30',	'::1'),
(2,	'2025-04-08 11:03:01',	'::1'),
(3,	'2025-04-08 11:03:21',	'::1'),
(4,	'2025-04-08 11:15:50',	'::1'),
(5,	'2025-04-08 11:22:28',	'::1'),
(6,	'2025-04-08 11:23:43',	'::1'),
(7,	'2025-04-08 11:31:15',	'::1'),
(8,	'2025-04-08 11:33:49',	'::1'),
(9,	'2025-04-08 11:34:35',	'::1'),
(10,	'2025-04-08 11:38:36',	'::1'),
(11,	'2025-04-08 11:38:49',	'::1'),
(12,	'2025-04-08 11:44:43',	'::1'),
(13,	'2025-04-08 11:44:52',	'::1');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `surname` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `username` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `password` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `role` enum('admin','user') CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

INSERT INTO `users` (`id`, `name`, `surname`, `username`, `phone`, `email`, `password`, `role`, `is_active`) VALUES
(1,	'Adam',	'Novák',	'novakadam',	'605205824',	'lezecadam@gmail.comm',	'$2y$10$Tto.yCXthjUHj/N1q.6mdeUFBipZQPpWvaN1x.JFKT8i86WFIIHhu',	'admin',	1),
(14,	'adfad',	'faefae',	'novakadam2',	'+420123456789',	'adam@akkon.cz',	'$2y$10$QdTxmnjGD2exb8qDXHN0je6Rg6yLdBjuat8k1lYqdxLe3GXI9SgJC',	'user',	1);

-- 2025-04-08 12:08:39
